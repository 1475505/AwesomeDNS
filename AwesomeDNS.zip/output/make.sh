#!/bin/sh

gcc test.c -o test
gcc client.c -o client
